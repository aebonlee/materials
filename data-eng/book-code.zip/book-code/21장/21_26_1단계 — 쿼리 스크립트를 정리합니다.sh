cd ~/lakehouse
mkdir -p scripts
cat > scripts/lakehouse_queries.sql << 'EOF'
-- scripts/lakehouse_queries.sql — 제4부 결과물: Trino 쿼리 스크립트
-- 실행: docker compose exec -T trino trino < scripts/lakehouse_queries.sql

-- 1. 연결 확인
SHOW CATALOGS;
SHOW SCHEMAS FROM iceberg;
SHOW TABLES FROM iceberg.lakehouse;

-- 2. 데이터 조회
SELECT * FROM iceberg.lakehouse.orders ORDER BY order_id;

-- 3. 집계
SELECT customer, count(*) AS orders, sum(amount) AS total
FROM iceberg.lakehouse.orders
GROUP BY customer ORDER BY total DESC;

SELECT channel,
       sum(amount) AS revenue,
       round(sum(amount) * 100.0 / sum(sum(amount)) OVER (), 1) AS pct
FROM iceberg.lakehouse.orders
GROUP BY channel ORDER BY revenue DESC;

SELECT * FROM iceberg.lakehouse.daily_sales ORDER BY order_date;

-- 4. 이력·타임 트래블
SELECT committed_at, snapshot_id, operation
FROM iceberg.lakehouse."orders$snapshots" ORDER BY committed_at;

SELECT file_path, record_count
FROM iceberg.lakehouse."orders$files";
EOF

docker compose exec mc mc cat local/raw/curated/quality_report.csv

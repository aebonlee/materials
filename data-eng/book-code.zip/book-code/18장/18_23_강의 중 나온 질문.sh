docker compose start rest

netstat -ano | findstr ":8080"

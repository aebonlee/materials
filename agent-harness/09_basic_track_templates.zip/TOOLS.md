# TOOLS.md — 쓸 수 있는 도구 (카드 한 장씩)

## [도구 이름]
- Purpose:
- Input:
- Output:
- When to Use:
- When NOT to Use:
- Failure Case (실패하면 어떻게 보이고, 그때 무엇을 하나):
- 권한 등급: AUTO / ASK / DENY

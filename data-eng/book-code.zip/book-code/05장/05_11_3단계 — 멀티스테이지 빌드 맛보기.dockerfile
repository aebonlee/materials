# 1단계 — 빌드 전용 (무거운 도구를 마음껏 씁니다)
FROM python:3.12 AS builder
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir --target=/deps -r requirements.txt

# 2단계 — 실행 전용 (필요한 것만 가져옵니다)
FROM python:3.12-slim
WORKDIR /app
COPY --from=builder /deps /deps
ENV PYTHONPATH=/deps
COPY . .
CMD ["python", "app.py"]

python3 speed.py

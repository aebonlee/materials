# CONTEXT.md — Agent 에게 보여줄 것

| 층 | 내용 | 언제 주나 |
|---|---|---|
| System Instruction (역할·규칙) | | 항상 |
| Task Context (이번 일) | | 요청마다 |
| User Context (누가·상황) | | 요청마다 |
| Document Context (자료) | | 필요한 단계 |
| History (이전 결과) | | 이어질 때 |
| Just-in-time (단계별) | | 그 단계 직전 |

자료 충돌 시 우선순위:

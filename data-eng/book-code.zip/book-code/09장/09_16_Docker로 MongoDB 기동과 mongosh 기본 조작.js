show dbs

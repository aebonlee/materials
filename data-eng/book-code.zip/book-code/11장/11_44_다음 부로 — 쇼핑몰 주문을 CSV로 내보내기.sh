# 7장의 de-mysql이 켜져 있고(docker ps에 Up), week2 가상환경에 pymysql이 있으면
cd ~/data-eng/week2
source .venv/bin/activate
python3 export_orders.py

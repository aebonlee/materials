head ~/data-eng/week3/shop_orders.csv
wc -l ~/data-eng/week3/shop_orders.csv

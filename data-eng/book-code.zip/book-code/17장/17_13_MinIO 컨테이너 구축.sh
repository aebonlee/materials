cd ~/lakehouse
cat > docker-compose.yml << 'EOF'
services:
  minio:
    image: pgsty/minio  # 공식 minio/minio는 Docker Hub에서 내려받을 수 없어(2026-10 확인) 같은 MinIO 빌드를 씁니다
    container_name: minio
    ports:
      - "9000:9000"
      - "9001:9001"
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    command: ["server", "/data", "--console-address", ":9001"]
    volumes:
      - minio-data:/data

  mc:
    image: pgsty/mc  # 공식 minio/mc는 Docker Hub에서 내려받을 수 없어(2026-10 확인) 같은 MinIO 빌드를 씁니다
    container_name: mc
    depends_on:
      - minio
    environment:
      MC_HOST_local: http://minioadmin:minioadmin@minio:9000  # mc의 별칭 local — 컨테이너를 다시 만들어도 남습니다
    entrypoint: ["/bin/sh", "-c", "sleep infinity"]
    volumes:
      - ./data:/data

volumes:
  minio-data:
EOF

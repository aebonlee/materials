use logdb

docker compose exec spark-iceberg spark-sql \
  --packages org.apache.hadoop:hadoop-aws:3.3.4 \
  --conf spark.hadoop.fs.s3a.endpoint=http://minio:9000 \
  --conf spark.hadoop.fs.s3a.access.key=minioadmin \
  --conf spark.hadoop.fs.s3a.secret.key=minioadmin \
  --conf spark.hadoop.fs.s3a.path.style.access=true \
  -e 'CREATE TABLE demo.lakehouse.orders_clean USING iceberg AS SELECT * FROM parquet.`s3a://raw/curated/orders_clean.parquet`;' 2>&1 | grep -E "already retrieved|Time taken|Error|Exception"

cd ~/lakehouse
docker compose exec mc mc ls local/raw/curated/

# safe_pick.py — 없을 수 있는 값은 검사하고 넘어갑니다 (새 파일)
import requests
from bs4 import BeautifulSoup

headers = {'User-Agent': 'data-eng-class-crawler/1.0 (learning purpose)'}
res = requests.get('https://quotes.toscrape.com/', headers=headers, timeout=10)
soup = BeautifulSoup(res.text, 'html.parser')


def pick(el, selector, default=None):
    found = el.select_one(selector)
    return found.get_text(strip=True) if found else default

for q in soup.select('div.quote'):
    print(pick(q, 'small.author'), '|', pick(q, 'span.missing', '(없음)'))

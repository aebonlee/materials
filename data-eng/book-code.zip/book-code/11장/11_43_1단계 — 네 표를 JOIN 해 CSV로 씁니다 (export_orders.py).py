# export_orders.py — shop DB의 주문 품목을 CSV로 내보냅니다 (10장의 네 표 JOIN → 12장의 입력 파일)
import csv
from pathlib import Path
import pymysql

conn = pymysql.connect(host='127.0.0.1', port=3306, user='root', password='dataeng123',
                       database='shop', charset='utf8mb4')

# 한 행 = 주문 품목(order_items 한 행). amount는 수량 × 주문 당시 단가(unit_price)
SQL = """
SELECT o.id                        AS order_id,
       o.ordered_at,
       c.name                      AS customer_name,
       p.name                      AS product_name,
       oi.quantity,
       oi.unit_price,
       oi.quantity * oi.unit_price AS amount
FROM order_items oi
JOIN orders    o ON o.id = oi.order_id
JOIN customers c ON c.id = o.customer_id
JOIN products  p ON p.id = oi.product_id
ORDER BY o.id, p.name
"""
with conn.cursor() as cur:
    cur.execute(SQL)
    rows = cur.fetchall()
    header = [col[0] for col in cur.description]   # 열 이름 7개
conn.close()

out = Path.home() / 'data-eng' / 'week3' / 'shop_orders.csv'
out.parent.mkdir(parents=True, exist_ok=True)
with open(out, 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(header)
    w.writerows(rows)

orders = {r[0] for r in rows}
total = sum(r[6] for r in rows)
print(f'{out} 에 썼습니다')
print(f'품목 {len(rows)}행 · 주문 {len(orders)}건 · amount 합계 {total:,}')

brew install shellcheck

# TOOLS.md — Agent 가 쓸 수 있는 도구

## FILE READ
- Purpose: 저장소 파일 읽기 · When NOT to Use: 저장소 밖 경로 · Failure Case: 파일 없음 → 멈추고 보고

## SHELL
- Purpose: 테스트 · 빌드 실행 · When NOT to Use: 삭제 · 네트워크 발송 · Failure Case: 비정상 종료 → 출력 그대로 보고

## FILE WRITE (ASK)
- Purpose: 코드 · 문서 수정 · When NOT to Use: 테스트 파일 · 설정 파일(허가 전) · Failure Case: 쓰기 실패 → 멈춤

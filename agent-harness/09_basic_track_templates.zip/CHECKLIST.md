# CHECKLIST.md — 잘했는지 판정하는 기준

| 기준 | 내 Agent 의 구체 기준 | 확인 방법 | 통과/실패 |
|---|---|---|---|
| Accuracy 정확성 | | | |
| Completeness 완전성 | | | |
| Grounding 근거 | | | |
| Format 형식 | | | |
| Safety 안전 | | | |
| Efficiency 효율 | | | |

판정: 전부 통과 → PASS / Format·Completeness 실패 → RETRY(실패 항목만 붙여 재시도) / Safety 실패 또는 재시도 소진 → HUMAN REVIEW

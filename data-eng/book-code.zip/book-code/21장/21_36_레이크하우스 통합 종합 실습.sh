docker compose exec -T trino trino --execute "DESCRIBE iceberg.lakehouse.orders_clean; SHOW TABLES FROM iceberg.lakehouse;"

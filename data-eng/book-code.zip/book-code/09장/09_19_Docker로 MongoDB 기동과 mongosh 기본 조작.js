show collections

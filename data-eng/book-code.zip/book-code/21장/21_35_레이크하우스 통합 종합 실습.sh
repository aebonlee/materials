docker compose exec -T trino trino --execute "SELECT count(*) AS rows, CAST(sum(amount) AS bigint) AS amount_sum, min(order_date), max(order_date) FROM iceberg.lakehouse.orders_clean;"

# EVAL.md — 완료를 판정하는 검증

## 자동 검증 (명령)
```
npm test
npm run lint
```

## 사람 확인 (HUMAN CHECKPOINT)
- [ ] SPEC.md 의 완료 정의를 만족하는가
- [ ] 건드리면 안 되는 파일이 그대로인가
- [ ] 새 의존성이 있으면 이유가 적혀 있는가

## 판정
- 자동 검증 통과 + 사람 확인 통과 → PASS
- 자동 검증 실패 → 실패 출력을 붙여 RETRY (최대 3회)
- 3회 소진 · 같은 오류 반복 → HUMAN REVIEW
